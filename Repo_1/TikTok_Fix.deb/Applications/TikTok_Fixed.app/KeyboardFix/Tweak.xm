#import <UIKit/UIKit.h>

%hook UIViewController

- (void)viewDidAppear:(BOOL)animated {
    %orig;
    
    // Check if tap gesture already exists
    BOOL hasTapGesture = NO;
    if ([self.view respondsToSelector:@selector(gestureRecognizers)]) {
        for (UIGestureRecognizer *gest in self.view.gestureRecognizers) {
            if ([gest isKindOfClass:[UITapGestureRecognizer class]]) {
                hasTapGesture = YES;
                break;
            }
        }
    }
    
    if (!hasTapGesture) {
        // endEditing: was introduced in iOS 2.0, UITapGestureRecognizer in iOS 3.2
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self.view action:@selector(endEditing:)];
        [tap setCancelsTouchesInView:NO];
        [self.view addGestureRecognizer:tap];
        [tap release]; // For old non-ARC environments
    }
}

%end

%hook UITextField
- (void)didMoveToWindow {
    %orig;
    // Set return key to Done if it's default
    if ([self respondsToSelector:@selector(setReturnKeyType:)]) {
        if (self.returnKeyType == UIReturnKeyDefault) {
            self.returnKeyType = UIReturnKeyDone;
        }
    }
}
%end
