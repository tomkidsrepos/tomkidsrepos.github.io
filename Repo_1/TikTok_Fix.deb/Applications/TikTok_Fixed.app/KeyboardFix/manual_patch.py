import struct
import os

def patch_macho(path, dylib_path):
    with open(path, "rb") as f:
        data = bytearray(f.read())

    # Mach-O Header (32-bit)
    # magic, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags
    magic = struct.unpack("<I", data[:4])[0]
    if magic != 0xfeedface: # MH_MAGIC
        print("Error: Not a 32-bit Mach-O binary (Little Endian expected)")
        return

    ncmds, sizeofcmds = struct.unpack("<II", data[16:24])
    
    # Path of dylib must be padded to 4 or 8 bytes
    dylib_path_bytes = dylib_path.encode("utf-8") + b"\x00"
    padded_path_len = (len(dylib_path_bytes) + 3) & ~3
    dylib_path_bytes = dylib_path_bytes.ljust(padded_path_len, b"\x00")
    
    # LC_LOAD_DYLIB command size: 24 bytes + path length
    cmd_size = 24 + padded_path_len
    
    # New header values
    new_ncmds = ncmds + 1
    new_sizeofcmds = sizeofcmds + cmd_size
    
    # Check if there is enough space (padding after load commands)
    # Usually there is 1000+ bytes of padding before the first segment data
    offset = 28 + sizeofcmds
    if data[offset:offset+cmd_size] != b"\x00" * cmd_size:
        print("Warning: Padding space is not empty, but we will try to overwrite it.")

    # Build LC_LOAD_DYLIB command
    # cmd (0xc), cmdsize, name_offset (24), timestamp (2), current_version (0), compatibility_version (0)
    lc_load_dylib = struct.pack("<IIIIII", 0xc, cmd_size, 24, 2, 0, 0) + dylib_path_bytes
    
    # Apply changes
    data[16:20] = struct.pack("<I", new_ncmds)
    data[20:24] = struct.pack("<I", new_sizeofcmds)
    data[offset:offset+cmd_size] = lc_load_dylib
    
    with open(path + "_patched", "wb") as f:
        f.write(data)
    print(f"Success: Patched {path}")

if __name__ == "__main__":
    patch_macho("/Users/tuanem/Desktop/TikTok.app/TikTok_armv7", "@executable_path/TikTokKeyboardFix.dylib")
