import lief
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BINARY_PATH = os.path.join(BASE_DIR, "..", "TikTok")
DYLIB_NAME = "@executable_path/TikTokKeyboardFix.dylib"

def patch():
    if not os.path.exists(BINARY_PATH):
        print(f"Error: Binary not found at {BINARY_PATH}")
        return

    print(f"[*] Loading Fat Binary: {BINARY_PATH}")
    fat_binary = lief.MachO.parse(BINARY_PATH)
    
    if fat_binary is None:
        print("Error: Could not parse binary.")
        return

    for binary in fat_binary:
        cpu_type = binary.header.cpu_type
        cpu_subtype = binary.header.cpu_subtype
        
        # Chỉ inject vào armv7 (subtype 9), bỏ qua armv6 (subtype 6)
        # CPU_TYPE_ARM = 12
        if cpu_type == 12 and cpu_subtype == 9:
            print(f"[*] Patching armv7 slice (Type: {cpu_type}, Subtype: {cpu_subtype})")
            
            already_injected = False
            for cmd in binary.commands:
                if isinstance(cmd, lief.MachO.DylibCommand):
                    if cmd.name == DYLIB_NAME:
                        already_injected = True
                        break
            
            if not already_injected:
                binary.add_library(DYLIB_NAME)
                print("    [+] Injected TikTokKeyboardFix.dylib")
            else:
                print("    [-] Already injected")
        else:
            print(f"[-] Skipping architecture (Type: {cpu_type}, Subtype: {cpu_subtype}) - Likely armv6")

    output_path = BINARY_PATH + "_patched"
    fat_binary.write(output_path)
    os.chmod(output_path, 0o755)
    print("\n[!] XONG! Hãy thử lại với file TikTok_patched này.")

if __name__ == "__main__":
    patch()
