Source info: 
iosbinpack64 and binpack: http://newosxbook.com/tools/iOSBinaries.html
Fish shell: https://fishshell.com
zip, unzip: http://infozip.sourceforge.net
bzip2: https://sourceware.org/bzip2/
unrar: https://www.rarlab.com/
gzip: https://www.gnu.org/software/gzip/
7z: https://www.7-zip.org