precision lowp float;

varying vec2 videoCoordinate;

uniform sampler2D filteredOriginalPicture;
uniform sampler2D filteredClahePicture;

void main() {
    vec4 color = texture2D(filteredClahePicture, videoCoordinate);
    color.r = color.r * 0.5;
    gl_FragColor = color;
}