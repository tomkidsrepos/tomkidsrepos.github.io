attribute vec4 position;
attribute vec2 inputTextureCoordinate;
attribute vec2 inputPhotoCoordinate;

varying vec2 textureCoordinate;
varying vec2 videoCoordinate;

uniform mat3 u_textureTransform;
uniform bool u_enableTextureTransform;

void main() {
    gl_Position = position;
    textureCoordinate = inputTextureCoordinate.xy;
    
    if (u_enableTextureTransform) {
        vec3 offset = vec3(0.5, 0.5, 0.0);
        vec3 texel = vec3(inputPhotoCoordinate, 0) - offset;
        texel = u_textureTransform * texel;
        texel = texel + offset;
        videoCoordinate = vec2(texel);
        
    } else {
        videoCoordinate = inputPhotoCoordinate.xy;
    }
}
