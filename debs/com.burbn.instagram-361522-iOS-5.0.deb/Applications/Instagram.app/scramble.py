import sys
import fileinput

from crypto_mapper import scramble_as_cstyle_hex_array

def convert_xxd_string_to_python_string(xxd_str):
    hex_characters = xxd_str.split(',')
    hex_to_string = ''.join([ chr(int(c.strip(), 16)) for c in hex_characters ])
    return hex_to_string

def encrypt_xxd_string(xxd_str):
    plaintext_string = convert_xxd_string_to_python_string(xxd_str)
    return scramble_as_cstyle_hex_array(plaintext_string)

if __name__ == '__main__':
    full_str = sys.stdin.read().strip()
    print encrypt_xxd_string(full_str)