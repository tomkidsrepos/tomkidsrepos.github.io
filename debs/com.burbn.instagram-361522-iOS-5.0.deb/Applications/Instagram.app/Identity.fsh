precision lowp float;

varying vec2 videoCoordinate;

uniform sampler2D picture;

void main() {
    gl_FragColor = texture2D(picture, videoCoordinate);
}