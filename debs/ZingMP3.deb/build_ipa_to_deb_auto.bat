@echo off
chcp 65001 >nul
setlocal

echo ================================
echo AUTO BUILD APP TO DEB - TOMKIDS
echo ================================
echo.

set /p APPPATH=Dan duong dan thu muc app package: 

if "%APPPATH%"=="" (
    echo Chua nhap duong dan.
    pause
    exit /b
)

set "WIN_SCRIPT=%TEMP%\tomkids_build_deb.sh"
set "LOG_FILE=%TEMP%\tomkids_build_deb_log.txt"

> "%WIN_SCRIPT%" (
echo #!/bin/bash
echo set -e
echo.
echo INPUT_PATH="$1"
echo REPO_DIR="/mnt/d/GitHub/cydia"
echo DEB_DIR="$REPO_DIR/debs"
echo ICON_DIR="$REPO_DIR/icons"
echo.
echo convert_path^(^) {
echo   local p="$1"
echo   p="${p//\\//}"
echo   p="${p/#\/\/wsl.localhost\/Ubuntu/}"
echo   p="${p/#\/\/wsl$\/Ubuntu/}"
echo   if [[ "$p" =~ ^([A-Za-z]):/ ]]; then
echo     drive="${BASH_REMATCH[1],,}"
echo     p="/mnt/$drive${p:2}"
echo   fi
echo   echo "$p"
echo }
echo.
echo APP_DIR="$(convert_path "$INPUT_PATH")"
echo echo "APP_DIR=$APP_DIR"
echo.
echo if [ ! -d "$APP_DIR" ]; then
echo   echo "ERROR: Thu muc khong ton tai: $APP_DIR"
echo   exit 1
echo fi
echo.
echo CONTROL="$APP_DIR/DEBIAN/control"
echo if [ ! -f "$CONTROL" ]; then
echo   echo "ERROR: Khong thay DEBIAN/control"
echo   exit 1
echo fi
echo.
echo find "$APP_DIR" -name "*Zone.Identifier*" -delete
echo.
echo PACKAGE="$(grep -m1 '^Package:' "$CONTROL" ^| cut -d':' -f2- ^| xargs)"
echo NAME="$(grep -m1 '^Name:' "$CONTROL" ^| cut -d':' -f2- ^| xargs)"
echo VERSION="$(grep -m1 '^Version:' "$CONTROL" ^| cut -d':' -f2- ^| xargs)"
echo ARCH="$(grep -m1 '^Architecture:' "$CONTROL" ^| cut -d':' -f2- ^| xargs)"
echo.
echo [ -z "$PACKAGE" ] ^&^& echo "ERROR: Thieu Package trong control" ^&^& exit 1
echo [ -z "$VERSION" ] ^&^& VERSION="1.0"
echo [ -z "$ARCH" ] ^&^& ARCH="iphoneos-arm"
echo.
echo APP_BUNDLE="$(find "$APP_DIR/Applications" -maxdepth 1 -type d -name "*.app" ^| head -n 1)"
echo [ -z "$APP_BUNDLE" ] ^&^& echo "ERROR: Khong thay thu muc .app" ^&^& exit 1
echo echo "APP_BUNDLE=$APP_BUNDLE"
echo.
echo EXECUTABLE="$(python3 -c "import sys,plistlib; p=plistlib.load(open(sys.argv[1],'rb')); print(p.get('CFBundleExecutable',''))" "$APP_BUNDLE/Info.plist" 2^>/dev/null ^| head -n 1)"
echo.
echo if [ -z "$EXECUTABLE" ] ^|^| [ ! -f "$APP_BUNDLE/$EXECUTABLE" ]; then
echo   EXECUTABLE="$(find "$APP_BUNDLE" -maxdepth 1 -type f ! -name "*.*" -printf "%%f\n" ^| head -n 1)"
echo fi
echo.
echo if [ -n "$EXECUTABLE" ] ^&^& [ -f "$APP_BUNDLE/$EXECUTABLE" ]; then
echo   echo "EXECUTABLE=$EXECUTABLE"
echo   chmod 755 "$APP_BUNDLE/$EXECUTABLE"
echo else
echo   echo "WARNING: Khong tim thay executable"
echo fi
echo.
echo mkdir -p "$ICON_DIR" "$DEB_DIR"
echo ICON_SRC="$APP_DIR/usr/lib/dpkg/info/$PACKAGE/icon.png"
echo ICON_FILE="${PACKAGE//./_}.png"
echo.
echo if [ -f "$ICON_SRC" ]; then
echo   cp "$ICON_SRC" "$ICON_DIR/$ICON_FILE"
echo   ICON_URL="http://tomkidss.github.io/cydia/icons/$ICON_FILE"
echo   if grep -q '^Icon:' "$CONTROL"; then
echo     sed -i "s#^Icon:.*#Icon: $ICON_URL#" "$CONTROL"
echo   else
echo     printf "\nIcon: %%s\n" "$ICON_URL" ^>^> "$CONTROL"
echo   fi
echo   echo "ICON=$ICON_URL"
echo else
echo   echo "WARNING: Khong thay icon tai usr/lib/dpkg/info/$PACKAGE/icon.png"
echo fi
echo.
echo chmod -R 755 "$APP_DIR"
echo chmod 755 "$APP_DIR/DEBIAN"
echo chmod 644 "$CONTROL"
echo printf "\n" ^>^> "$CONTROL"
echo.
echo BUILD_PARENT="$(dirname "$APP_DIR")"
echo BUILD_NAME="$(basename "$APP_DIR")"
echo cd "$BUILD_PARENT"
echo.
echo rm -f "$BUILD_NAME.deb"
echo dpkg-deb -Zgzip -b "$BUILD_NAME"
echo.
echo DEB_NAME="${PACKAGE}_${VERSION}_${ARCH}.deb"
echo mv -f "$BUILD_NAME.deb" "$DEB_NAME"
echo cp -f "$DEB_NAME" "$DEB_DIR/"
echo echo "DEB_CREATED=$DEB_DIR/$DEB_NAME"
echo.
echo cd "$REPO_DIR"
echo rm -f Packages Packages.bz2 Release
echo dpkg-scanpackages -m debs /dev/null ^> Packages
echo bzip2 -k -f Packages
echo.
echo cat ^> Release ^<^<'EOF'
echo Origin: Tomkids's Cydia
echo Label: Tomkids Cydia
echo Suite: stable
echo Version: 1.0
echo Codename: ios
echo Architectures: iphoneos-arm
echo Components: main
echo Description: Kho ứng dụng ^& tweak iOS cổ của Tomkids
echo EOF
echo.
echo git add .
echo if git diff --cached --quiet; then
echo   echo "Khong co thay doi Git."
echo else
echo   git commit -m "Auto build $NAME package"
echo   git push
echo fi
echo.
echo echo "DONE"
)

for /f "delims=" %%i in ('wsl wslpath -a "%WIN_SCRIPT%"') do set "WSL_SCRIPT=%%i"

echo.
echo Dang chay build...
echo Log: %LOG_FILE%
echo.

wsl bash "%WSL_SCRIPT%" "%APPPATH%" > "%LOG_FILE%" 2>&1

type "%LOG_FILE%"

echo.
echo ================================
echo KET THUC BUILD
echo ================================
pause